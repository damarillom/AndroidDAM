package com.example.ausias.pt13;

import static org.junit.Assert.*;

public class ProvesTest {

}